CREATE TABLE nutrition (
    id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name           VARCHAR(255) NOT NULL,
    portion_name   VARCHAR(255),
    portion_weight DECIMAL(10, 2) CHECK (portion_weight > 0),
    category_id    BIGINT,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_nutrition_category
        FOREIGN KEY (category_id) REFERENCES category (id)
        ON DELETE SET NULL
);

CREATE INDEX idx_nutrition_category_id ON nutrition (category_id);
CREATE INDEX idx_nutrition_name_lower ON nutrition (LOWER(name));

INSERT INTO nutrition (name, portion_name, portion_weight, category_id) VALUES
('Яблоко', 'шт', 150.00, 1),
('Банан', 'шт', 120.00, 1),
('Апельсин', 'шт', 130.00, 1),
('Груша', 'шт', 140.00, 1),
('Морковь', 'шт', 100.00, 2),
('Огурец', 'шт', 150.00, 2),
('Помидор', 'шт', 120.00, 2),
('Молоко', 'стакан', 200.00, 3),
('Творог', '100 г', 100.00, 3),
('Йогурт', 'стакан', 200.00, 3),
('Куриная грудка', '100 г', 100.00, 4),
('Говядина', '100 г', 100.00, 4),
('Лосось', '100 г', 100.00, 5),
('Креветки', '100 г', 100.00, 5),
('Рис', '100 г', 100.00, 6),
('Гречка', '100 г', 100.00, 6),
('Овсянка', '100 г', 100.00, 6),
('Чечевица', '100 г', 100.00, 7),
('Миндаль', '30 г', 30.00, 8),
('Грецкий орех', '30 г', 30.00, 8),
('Хлеб белый', 'кусок', 30.00, 9),
('Шоколад молочный', '25 г', 25.00, 10),
('Вода питьевая негазированная', 'бутылка 0.5л', 500.00, 12),
('Вода газированная', 'бутылка 0.5л', 500.00, 12),
('Вода минеральная', 'бутылка 0.5л', 500.00, 12),
('Вода кокосовая', 'стакан', 250.00, 12),
('Сок апельсиновый', 'стакан', 200.00, 27),
('Чай зелёный', 'чашка', 200.00, 26),
('Кофе чёрный', 'чашка', 200.00, 26),
('Изюм', '30 г', 30.00, 28);
package com.app.nutrition_service.services.subservices;

import com.app.nutrition_service.dto.NutritionDTO;
import com.app.nutrition_service.exceptions.DrinkNotFoundException;
import com.app.nutrition_service.exceptions.DrinksNotFoundException;
import com.app.nutrition_service.mappers.NutritionMapper;
import com.app.nutrition_service.repositories.CategoryRepository;
import com.app.nutrition_service.repositories.NutritionRepository;
import com.app.nutrition_service.entities.Nutrition;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class DrinkService {
    private final NutritionRepository nutritionRepository;
    private final CategoryRepository categoryRepository;
    private final NutritionMapper nutritionMapper;


    public ResponseEntity<List<NutritionDTO>> getAllDrinks() throws DrinksNotFoundException {
        List<Nutrition> drinks = nutritionRepository.findByNutritionType("drink");
        if (drinks.isEmpty()){
            throw new DrinksNotFoundException();
        }

        return ResponseEntity.ok(
                nutritionMapper.toDtoList(drinks)
        );
    }

    public NutritionDTO getDrinkById(Long id) throws DrinkNotFoundException {
        Nutrition drink = nutritionRepository.findById(id).orElseThrow(DrinkNotFoundException::new);

        return nutritionMapper.toDto(drink);
    }

    public List<NutritionDTO> getDrinksByCategoryName(String categoryName) throws DrinksNotFoundException {
        categoryName = categoryName.toUpperCase();
        List<Nutrition> drinks = nutritionRepository.findByCategoryName(categoryName);
        if (drinks.isEmpty()){
            throw new DrinksNotFoundException();
        }

        return nutritionMapper.toDtoList(drinks);
    }

    public NutritionDTO createDrink(NutritionDTO dto) {
        Nutrition drink = nutritionMapper.toEntity(dto);
        Nutrition savedDrink = nutritionRepository.save(drink);

        return nutritionMapper.toDto(savedDrink);
    }

    public NutritionDTO updateDrink(Long id, NutritionDTO dto) throws DrinkNotFoundException {
        Nutrition drink = nutritionRepository.findById(id).orElseThrow(DrinkNotFoundException::new);
        nutritionMapper.updateEntity(dto, drink);
        Nutrition updatedDrink = nutritionRepository.save(drink);

        return nutritionMapper.toDto(updatedDrink);
    }

    public void deleteDrink(Long id) {
        if (!nutritionRepository.existsById(id)) {
            throw new RuntimeException("Drink not found");
        }

        nutritionRepository.deleteById(id);
    }

}

package com.app.nutrition_service.entities;

import com.app.nutrition_service.entities.Category;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(
        name = "nutrition",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_nutrition_name_category",
                        columnNames = {"name", "category_id"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Nutrition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "name")
    private String name;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "category_id",
            foreignKey = @ForeignKey(name = "fk_nutrition_category")
    )
    private Category category;
    @Column(name = "calories")
    private Double calories;
    @Column(name = "protein")
    private Double protein;
    @Column(name = "carbohydrates")
    private Double carbohydrates;
    @Column(name = "fat")
    private Double fat;
    @Column(name = "base_amount")
    private Double baseAmount = 100D;
    @Column(name = "base_unit")
    private String baseUnit;
    @Column(name = "unit_label")
    private String unitLabel;
    @Column(name = "unit_weight")
    private Double unitWeight;
}
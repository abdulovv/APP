package com.app.nutrition_service.mappers;

import com.app.nutrition_service.entities.Nutrition;
import com.app.nutrition_service.dto.NutritionDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring", uses = CategoryMapper.class)
public interface NutritionMapper {
    NutritionDTO toDto(Nutrition nutrition);

    List<NutritionDTO> toDtoList(List<Nutrition> drinks);

    Nutrition toEntity(NutritionDTO dto);

    List<Nutrition> toEntityList(List<NutritionDTO> drinksDto);

    @Mapping(target = "id", ignore = true)
    void updateEntity(NutritionDTO dto, @MappingTarget Nutrition drink);
}
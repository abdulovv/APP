package com.app.nutrition_service.repositories;

import com.app.nutrition_service.entities.Nutrition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NutritionRepository extends JpaRepository<Nutrition, Long> {
    List<Nutrition> findByCategoryName(String categoryName);

    List<Nutrition> findByNutritionType(String nutritionType);
}

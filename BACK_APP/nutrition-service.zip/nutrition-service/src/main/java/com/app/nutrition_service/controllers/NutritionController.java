package com.app.nutrition_service.controllers;

import com.app.nutrition_service.dto.NutritionDTO;
import com.app.nutrition_service.exceptions.DrinkNotFoundException;
import com.app.nutrition_service.exceptions.DrinksNotFoundException;
import com.app.nutrition_service.exceptions.FoodNotFoundException;
import com.app.nutrition_service.services.NutritionService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/nutrition")
public class NutritionController {
    private final NutritionService nutritionService;

    // ==================== DRINKS ====================
    @GetMapping("/drinks/all")
    public ResponseEntity<List<NutritionDTO>> getAllDrinks() throws DrinksNotFoundException {
        return nutritionService.getAllDrinks();
    }

    @GetMapping("/drinks/{id}")
    public NutritionDTO getDrinkById(@PathVariable(name = "id") Long id) throws DrinkNotFoundException {
        return nutritionService.getDrinkById(id);
    }

    @GetMapping("/drinks/category/{categoryName}")
    public List<NutritionDTO> getDrinksByCategoryName(@PathVariable("categoryName") String categoryName) throws DrinksNotFoundException {
        return nutritionService.getDrinkByCategoryName(categoryName);
    }

    @PostMapping("/drinks")
    public NutritionDTO createDrink(@RequestBody NutritionDTO dto) {
        return nutritionService.createDrink(dto);
    }

    @PutMapping("/drinks/{id}")
    public NutritionDTO updateDrink(
            @PathVariable Long id,
            @RequestBody NutritionDTO dto
    ) throws DrinkNotFoundException {
        return nutritionService.updateDrink(id, dto);
    }

    @DeleteMapping("/drinks/{id}")
    public void deleteDrink(@PathVariable(name = "id") Long id) {
        nutritionService.deleteDrink(id);
    }

    // ==================== FOOD ====================
    @GetMapping("/foods/all")
    public List<NutritionDTO> getAllFoods() {
        return nutritionService.getAllFoods();
    }

    @GetMapping("/foods/{id}")
    public NutritionDTO getFoodById(@PathVariable Long id) throws FoodNotFoundException {
        return nutritionService.getFoodById(id);
    }

    @PostMapping("/foods")
    public NutritionDTO createFood(@RequestBody NutritionDTO dto) {
        return nutritionService.createFood(dto);
    }

    @PutMapping("/foods/{id}")
    public NutritionDTO updateFood(
            @PathVariable Long id,
            @RequestBody NutritionDTO dto
    ) throws FoodNotFoundException {
        return nutritionService.updateFood(id, dto);
    }

    @DeleteMapping("/foods/{id}")
    public void deleteFood(@PathVariable Long id) throws FoodNotFoundException {
        nutritionService.deleteFood(id);
    }

}

package com.app.nutrition_service.services;

import com.app.nutrition_service.dto.NutritionDTO;
import com.app.nutrition_service.exceptions.DrinkNotFoundException;
import com.app.nutrition_service.exceptions.DrinksNotFoundException;
import com.app.nutrition_service.exceptions.FoodNotFoundException;
import com.app.nutrition_service.services.subservices.DrinkService;
import com.app.nutrition_service.services.subservices.FoodService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class NutritionService {
    private final FoodService foodService;
    private final DrinkService drinkService;
    private final CategoryService categoryService;

    // ==================== DRINK ====================
    public ResponseEntity<List<NutritionDTO>> getAllDrinks() throws DrinksNotFoundException {
        return drinkService.getAllDrinks();
    }

    public NutritionDTO getDrinkById(Long id) throws DrinkNotFoundException {
        return drinkService.getDrinkById(id);
    }

    public List<NutritionDTO> getDrinkByCategoryName(String categoryName) throws DrinksNotFoundException {
        return drinkService.getDrinksByCategoryName(categoryName);
    }

    public NutritionDTO createDrink(NutritionDTO dto) {
        return drinkService.createDrink(dto);
    }

    public NutritionDTO updateDrink(Long id, NutritionDTO dto) throws DrinkNotFoundException {
        return drinkService.updateDrink(id, dto);
    }

    public void deleteDrink(Long id) {
        drinkService.deleteDrink(id);
    }

    // ==================== FOOD ====================
    public List<NutritionDTO> getAllFoods() {
        return foodService.getAllFoods();
    }

    public NutritionDTO getFoodById(Long id) throws FoodNotFoundException {
        return foodService.getFoodById(id);
    }

    public NutritionDTO createFood(NutritionDTO dto) {
        return foodService.createFood(dto);
    }

    public NutritionDTO updateFood(Long id, NutritionDTO dto) throws FoodNotFoundException {
        return foodService.updateFood(id, dto);
    }

    public void deleteFood(Long id) throws FoodNotFoundException {
        foodService.deleteFood(id);
    }


}

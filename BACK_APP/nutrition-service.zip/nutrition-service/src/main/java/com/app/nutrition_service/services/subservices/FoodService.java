package com.app.nutrition_service.services.subservices;

import com.app.nutrition_service.dto.NutritionDTO;
import com.app.nutrition_service.entities.Nutrition;
import com.app.nutrition_service.exceptions.FoodNotFoundException;
import com.app.nutrition_service.mappers.NutritionMapper;
import com.app.nutrition_service.repositories.NutritionRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@AllArgsConstructor
public class FoodService {
    private final NutritionRepository nutritionRepository;
    private final NutritionMapper nutritionMapper;

    public List<NutritionDTO> getAllFoods() {
        List<Nutrition> foods = nutritionRepository.findAll();

        return nutritionMapper.toDtoList(foods);
    }

    public NutritionDTO getFoodById(Long id) throws FoodNotFoundException {
        Nutrition food = nutritionRepository.findById(id).orElseThrow(FoodNotFoundException::new);

        return nutritionMapper.toDto(food);
    }

    public NutritionDTO createFood(NutritionDTO dto) {
        Nutrition food = nutritionMapper.toEntity(dto);
        Nutrition savedFood = nutritionRepository.save(food);

        return nutritionMapper.toDto(savedFood);
    }

    public NutritionDTO updateFood(Long id, NutritionDTO dto) throws FoodNotFoundException {
        Nutrition food = nutritionRepository.findById(id).orElseThrow(FoodNotFoundException::new);
        nutritionMapper.updateEntity(dto, food);
        Nutrition updatedFood = nutritionRepository.save(food);

        return nutritionMapper.toDto(updatedFood);
    }

    public void deleteFood(Long id) throws FoodNotFoundException {
        if (!nutritionRepository.existsById(id)) {
            throw new FoodNotFoundException();
        }

        nutritionRepository.deleteById(id);
    }
}


package com.app.nutrition_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NutritionDTO {
    private Long id;
    private String name;
    private CategoryDTO category;
    private Double calories;
    private Double protein;
    private Double carbohydrates;
    private Double fat;
    private Double baseAmount = 100D;
    private String baseUnit;
    private String unitLabel;
    private Double unitWeight;
}

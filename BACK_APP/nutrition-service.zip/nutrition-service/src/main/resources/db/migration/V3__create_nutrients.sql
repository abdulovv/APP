CREATE TABLE nutrients (
    id   INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    unit VARCHAR(50)
);

INSERT INTO nutrients (id, name, unit) VALUES
(1,  'Белки', 'г'),
(2,  'Жиры', 'г'),
(3,  'Углеводы', 'г'),
(4,  'Клетчатка', 'г'),
(5,  'Сахар', 'г'),
(6,  'Натрий', 'мг'),
(7,  'Калий', 'мг'),
(8,  'Кальций', 'мг'),
(9,  'Железо', 'мг'),
(10, 'Витамин C', 'мг');

package com.app.nutrition_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
